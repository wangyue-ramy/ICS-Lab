/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
void trans_imp1(int M, int N, int A[N][M], int B[M][N], int blocksize);

char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    trans_imp1(M, N, A, B, 8);
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 
void trans_imp1(int M, int N, int A[N][M], int B[M][N], int blocksize)
{
    int i, j, k, l;
    for (i = 0; i < M; i += blocksize) 
    {
        for (j = 0; j < N; j += blocksize) 
        {
            // transpose the block beginning at [i,j]
            for (k = i; k < i + blocksize && k < M; ++k) 
            {
                for (l = j; l < j + blocksize && l < N; ++l) 
                {
                    B[k][l] = A[l][k];
                }
            }
        }
    }
}

char trans_imp1_a_desc[] = "blocksize = 2";
void trans_imp1_a(int M, int N, int A[N][M], int B[M][N])
{
    trans_imp1(M, N, A, B, 2);
}

char trans_imp1_b_desc[] = "blocksize = 8";
void trans_imp1_b(int M, int N, int A[N][M], int B[M][N])
{
    trans_imp1(M, N, A, B, 8);
}

char trans_imp1_c_desc[] = "blocksize = 12, (61, 67)";
void trans_imp1_c(int M, int N, int A[N][M], int B[M][N])
{
    trans_imp1(M, N, A, B, 12);
}

char trans_imp1_d_desc[] = "blocksize = 16";
void trans_imp1_d(int M, int N, int A[N][M], int B[M][N])
{
    trans_imp1(M, N, A, B, 13);
}

// 基本思路是把每一个矩阵都化为M = 8的矩阵
// 在这里做新老矩阵的一个坐标转换
void twoD2OneD(int *pi, int *pj, int *px, int M)
{
    (*px) = (*pi) * M + (*pj);
}

void oneD2TwoD(int *px, int *pi, int *pj, int M)
{
    (*pi) = (*px) / M;
    (*pj) = (*px) % M;
}

void old2New(int *pi, int *pj, int M)
{
    int x = 0;
    twoD2OneD(pi, pj, &x, M);
    oneD2TwoD(&x, pi, pj, 8);
}

void new2Old(int *pi, int *pj, int M)
{
    int x = 0;
    twoD2OneD(pi, pj, &x, 8);
    oneD2TwoD(&x, pi, pj, M);
}

char trans_imp2_desc[] = "imp2";
void trans_imp2(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, k, l, m, n, blocksize = 8, newM = blocksize, newN = M * N / newM;
    for (i = 0; i < newM; i += blocksize)
    {
        for (j = 0; j < newN; j += blocksize)
        {
            // transpose the block beginning at [i,j]
            for (k = i; k < i + blocksize; ++k)
            {
                for (l = j; l < j + blocksize; ++l)
                {
                    m = k;
                    n = l;
                    new2Old(&n, &m, M);
                    B[m][n] = A[n][m];
                }
            }
        }
    }
}

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

    registerTransFunction(trans_imp1_a, trans_imp1_a_desc);
    registerTransFunction(trans_imp1_b, trans_imp1_b_desc);
    registerTransFunction(trans_imp1_c, trans_imp1_c_desc);
    registerTransFunction(trans_imp1_d, trans_imp1_d_desc);
    registerTransFunction(trans_imp2, trans_imp2_desc);
}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

