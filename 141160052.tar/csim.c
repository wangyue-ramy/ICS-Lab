// 141160052
// 阮俊彬

#include "cachelab.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <setjmp.h>

#define bool int
#define true 1
#define false 0

typedef struct boolTuple
{
    bool fst, snd;
} BoolTuple;

#define AddressLength 64
#define getTagLength(s, b) (AddressLength - s - b)
#define getTag(address, t) (address >> (AddressLength - t))
#define getSetIndex(address, s, b) ((address & ~(0xffffffffffffffff << (s + b))) >> b)
#define getBlockOffset(address, b) (address & ~(0xffffffffffffffff << (b)))

// 这是高速缓存行的结构定义，分别是isValid——有效位、tag——标记位、block——缓存块
typedef struct cacheLine
{
    bool isValid;
    unsigned long int tag;
    char *block;
    unsigned long int time;
} CacheLine;

// 这是高速缓存组的结构定义，每一个组有E个高速缓存行
typedef CacheLine* CacheSet;

// 这是高速缓存的结构定义，高速缓存有S组
typedef CacheSet* Cache;

unsigned int t, s, b, E;
unsigned int long time = 0;
Cache cache;

// 用于处理一个奇怪的错误
jmp_buf End;

bool initCache()
{
    int i, j, S = pow(2, s); // , B = pow(2, b);

    t = getTagLength(s, b);

    cache = (Cache)malloc(sizeof(CacheSet) * S);
    for (i = 0; i < S; i++)
    {
        cache[i] = (CacheSet)(Cache)malloc(sizeof(CacheLine) * E);
        for (j = 0; j < E; j++)
        {
            // (cache)[i][j].block = (char*)malloc(sizeof(char) * B);
            (cache)[i][j].block = NULL;
            (cache)[i][j].isValid = false;
            (cache)[i][j].time = 0;
        }
    }

    return true;
}

void freeCache()
{
    int i, S = pow(2, s);
    for (i = 0; i < S; i++)
    {
        free((void*)cache[i]);
    }
    free((void*)cache);
}

// fst表征是否命中，true表示命中，false表示不命中
// snd表征是否驱逐，true表示驱逐，false表示不驱逐
BoolTuple insert (unsigned long int address, unsigned int size)
{
    unsigned long int tag, setIndex; //, blockOffset;
    // i会作为后面访问高速缓存行的一个计数器
    // 怀疑测试程序csim-ref出错，如果我把S = s，能得到和测试程序一样的结果
    // S = pow(2, s)，用yi2.trace测试前面8个不应该有驱逐，因为还处在冷不命中阶段
    int i; // S = pow(2, s); // = s
    // j会去记住time最小的行，以方便可能的替换
    // 由于我们只有一个程序在测试，没有多进程，也不会有多进程切换带来的冷不命中
    // 所以time == 0的行一定是刚开始没有被填充的行
    // 即只要去找time最小的行替换掉，一定实现的就是LRU
    int j = 0;
    BoolTuple bt;

    tag = getTag(address, t);
    setIndex = getSetIndex(address, s, b);
    // blockOffset = getBlockOffset(address, b);

    CacheSet *c = &((cache)[setIndex]);

    for (i = 0; i < E; i++)
    {
        if ((*c)[i].isValid && (*c)[i].tag == tag)
        {
            (*c)[i].time = (++time);
            bt.fst = true;
            bt.snd = false;
            return bt;
        }
        else
        {
            if ((*c)[j].time > (*c)[i].time)
            {
                j = i;
            }
        }
    }

    if ((*c)[j].isValid)
    {
        bt.snd = true;
    }
    else
    {
        bt.snd = false;
    }
    (*c)[j].isValid = true;
    (*c)[j].tag = tag;
    (*c)[j].time = (++time);
    bt.fst = false;
    return bt;
}

unsigned long int hexString2Int(char *s)
{
    int i, sum = 0;

    if (s == NULL)
    {
        printf("s is NULL, hexString2Int\n");
        // exit(1);
        return 0xffffffffffffffff;
    }

    for (i = 0; s[i] != '\0'; i++)
    {
        if (s[i] >= '0' && s[i] <= '9')
        {
            sum = sum * 16 + s[i] - '0';
        }
        else if (s[i] >= 'a' && s[i] <= 'f')
        {
            sum = sum * 16 + s[i] - 'a' + 10;
        }
        else if (s[i] >= 'A' && s[i] <= 'F')
        {
            sum = sum * 16 + s[i] - 'A' + 10;
        }
        else
        {
            printf("error in hexString2Int.\n");
            exit(1);
        }
    }
    return sum;
}

/* void printSummary(int hits, int misses, int evictions)
{
    printf("hits:%d misses:%d evictions:%d\n", hits, misses, evictions);
} */

int main(int argc, char *argv[])
{
    // i用于处理把argv转换成sEb时不同情况的处理，address用于给insert传参数，size是insert的另外一个参数
    unsigned int i, size;
    // op用于处理IMSL
    char *op;
    // meetM用于帮助处理遇到M的情况
    bool meetM;
    unsigned long int address;
    char *tracefile;
    FILE *fp = NULL;
    char str[100], str_[100];
    BoolTuple bt;
    // 用于记录命中次数等
    int hit_count = 0, miss_count = 0, eviction_count = 0;

    if (argc == 9 || argc == 10)
    {
        if (argc == 9)
        {
            i = 0;
        }
        else
        {
            i = 1;
        }

        s = atoi(argv[2 + i]);
        E = atoi(argv[4 + i]);
        b = atoi(argv[6 + i]);
        tracefile = argv[8 + i];

        // printf("%d %d %d %s\n", s, E, b, tracefile);
        fp = fopen(tracefile, "r");
        if (fp == NULL)
        {
            printf("Can't open file!\n");
            return 0;
        }

        initCache();
        while (!feof(fp)) 
        {
            fgets(str, 100, fp);
            strcpy(str_, str);
            strtok(str_, "\n");
            // printf("%s\n", str);
            // printf("%s\t", strtok(str, " "));
            // printf("%d\t", hexString2Int(strtok(NULL, ",")));
            // printf("%d\n", atoi(strtok(NULL, " ")));
            op = strtok(str, " ");
            // op用于判断是不是I——指令装载，如果是，则直接抛弃
            if (op[0] == 'I')
            {
                continue;
            }
            
            if (op[0] == 'M')
            {
                meetM = true;
            }
            else
            {
                meetM = false;
            }

            address = hexString2Int(strtok(NULL, ","));
            // 一个很笨的错误处理
            if (address == 0xffffffffffffffff)
            {
                goto E;
            }
            size = atoi(strtok(NULL, " "));
M:          bt = insert(address, size);

            if (bt.fst)
            {
                hit_count++;
                printf("%s %s\n", str_, "hit");
            }
            else
            {
                miss_count++;
                if (bt.snd)
                {
                    eviction_count++;
                    printf("%s %s\n", str_, "miss eviction");
                }
                else
                {
                    printf("%s %s\n", str_, "miss");
                }
            }

            if (meetM)
            {
                meetM = false;
                goto M;
            }
        } 
        fclose(fp);
        fp = NULL;

E:      printSummary(hit_count, miss_count, eviction_count);
        freeCache();
    }
    else
    {
        printf("[-v] -s <s> -E <E> -b <b> -t <tracefile>\n");
    }
}
